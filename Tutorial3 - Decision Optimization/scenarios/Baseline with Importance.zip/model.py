from docplex.mp.model import *
from docplex.mp.utils import *
from docplex.util.status import JobSolveStatus
from docplex.mp.conflict_refiner import ConflictRefiner, VarUbConstraintWrapper, VarLbConstraintWrapper
from docplex.mp.relaxer import Relaxer
import time
import sys
import operator

import pandas as pd
import numpy as np
import math

import codecs
import sys

# Handle output of unicode strings
if sys.version_info[0] < 3:
    sys.stdout = codecs.getwriter('utf8')(sys.stdout)


# Label constraint
def helper_add_labeled_cplex_constraint(mdl, expr, label, context=None, columns=None):
    global expr_counter
    if isinstance(expr, np.bool_):
        expr = expr.item()
    if isinstance(expr, bool):
        pass  # Adding a trivial constraint: if infeasible, docplex will raise an exception it is added to the model
    else:
        expr.name = '_L_EXPR_' + str(len(expr_to_info) + 1)
        if columns:
            ctxt = ", ".join(str(getattr(context, col)) for col in columns)
        else:
            if context:
                ctxt = context.Index if isinstance(context.Index, str) is not None else ", ".join(context.Index)
            else:
                ctxt = None
        expr_to_info[expr.name] = (label, ctxt)
    mdl.add(expr)

def helper_get_column_name_for_property(property):
    return helper_property_id_to_column_names_map.get(property, 'unknown')


def helper_get_index_names_for_type(dataframe, type):
    if not is_pandas_dataframe(dataframe):
        return None
    return [name for name in dataframe.index.names if name in helper_concept_id_to_index_names_map.get(type, [])]


helper_concept_id_to_index_names_map = {
    'cItem': ['id_of_CountyDemand'],
    'AllocationParameters': ['id_of_AllocationParameters'],
    'CountyDemand': ['id_of_CountyDemand'],
    'Product': ['id_of_Product'],
    'County': ['id_of_County']}
helper_property_id_to_column_names_map = {
    'AllocationParameters.max_budget': 'max_budget',
    'CountyDemand.product': 'product_',
    'CountyDemand.demand': 'demand',
    'County.county': 'county',
    'CountyDemand.county': 'county',
    'Product.product': 'product_',
    'Product.importanceFactor': 'importanceFactor'}


# Data model definition for each table
# Data collection: list_of_AllocationParameters ['max_budget', '__line']
# Data collection: list_of_County ['county']
# Data collection: list_of_CountyDemand ['county', 'demand', 'product_', '__line']
# Data collection: list_of_Product ['importanceFactor', 'product_']

# Create a pandas Dataframe for each data table
list_of_AllocationParameters = inputs[u'AllocationParameters']
list_of_AllocationParameters = list_of_AllocationParameters[[u'max_budget']].copy()
list_of_AllocationParameters.rename(columns={u'max_budget': 'max_budget'}, inplace=True)
list_of_County = inputs[u'County']
list_of_County = list_of_County[[u'county']].copy()
list_of_County.rename(columns={u'county': 'county'}, inplace=True)
list_of_CountyDemand = inputs[u'CountyDemand']
list_of_CountyDemand = list_of_CountyDemand[[u'county', u'demand', u'product']].copy()
list_of_CountyDemand.rename(columns={u'county': 'county', u'demand': 'demand', u'product': 'product_'}, inplace=True)
list_of_Product = inputs[u'Product']
list_of_Product = list_of_Product[[u'importanceFactor', u'product']].copy()
list_of_Product.rename(columns={u'importanceFactor': 'importanceFactor', u'product': 'product_'}, inplace=True)

# Set index when a primary key is defined
list_of_AllocationParameters.index.name = 'id_of_AllocationParameters'
list_of_County.set_index('county', inplace=True)
list_of_County.sort_index(inplace=True)
list_of_County.index.name = 'id_of_County'
list_of_CountyDemand.index.name = 'id_of_CountyDemand'
list_of_Product.set_index('product_', inplace=True)
list_of_Product.sort_index(inplace=True)
list_of_Product.index.name = 'id_of_Product'






def build_model():
    mdl = Model()

    # Definition of model variables
    list_of_CountyDemand['allocationVar'] = mdl.integer_var_list(len(list_of_CountyDemand))
    list_of_CountyDemand['selectionVar'] = mdl.binary_var_list(len(list_of_CountyDemand))


    # Definition of model
    # Objective cMaximizeGoalSelect-
    # Combine weighted criteria: 
    # 	cMaximizeGoalSelect cMaximizeGoalSelect 1.2{
    # 	numericExpr = decisionPath(cAllocation[CountyDemand]),
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null} with weight 5.0
    # 	cEqualizeGapGoal cEqualizeGapGoal 1.2{
    # 	origin = CountyDemand,
    # 	referenceNumericExpr = CountyDemand / demand,
    # 	numericExpr = decisionPath(CountyDemand / inverse(cAllocation.CountyDemand)),
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null} with weight 5.0
    # 	cMaximizeGoalSelect cMaximizeGoalSelect 1.2{
    # 	numericExpr = total cAllocation[CountyDemand] / CountyDemand / product / importanceFactor,
    # 	scaleFactorExpr = 1,
    # 	(static) goalFilter = null} with weight 7.0
    agg_CountyDemand_allocationVar_SG1 = mdl.sum(list_of_CountyDemand.allocationVar)
    list_of_CountyDemand_data = list_of_CountyDemand[list_of_CountyDemand.demand != 0].copy()
    list_of_CountyDemand_data['sub_goal_data'] = (list_of_CountyDemand_data.allocationVar / list_of_CountyDemand_data.demand) - (mdl.sum(list_of_CountyDemand_data.allocationVar) / np.sum(list_of_CountyDemand_data.demand))
    list_of_CountyDemand_data = list_of_CountyDemand_data.sub_goal_data.groupby(level=['id_of_CountyDemand']).sum().to_frame()
    agg_CountyDemand_SG2_data = mdl.sum(mdl.abs(value) for value in list_of_CountyDemand_data.sub_goal_data.values)
    join_CountyDemand_SG3 = list_of_CountyDemand.reset_index().join(list_of_Product.importanceFactor, on=['product_'], how='inner').set_index(['id_of_CountyDemand'])
    join_CountyDemand_SG3['conditioned_importanceFactor'] = join_CountyDemand_SG3.allocationVar * join_CountyDemand_SG3.importanceFactor
    agg_CountyDemand_conditioned_importanceFactor_SG3 = mdl.sum(join_CountyDemand_SG3.conditioned_importanceFactor)
    
    kpis_expression_list = [
        (-1, 16.0, agg_CountyDemand_allocationVar_SG1, 1, 0, u'total CountyDemand allocations'),
        (1, 16.0, agg_CountyDemand_SG2_data, 1, 0, u'gap between allocation and demand over CountyDemands'),
        (-1, 64.0, agg_CountyDemand_conditioned_importanceFactor_SG3, 1, 0, u'total importanceFactor of product of CountyDemands over all allocations')]
    custom_code.update_goals_list(kpis_expression_list)
    
    for _, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list:
        mdl.add_kpi(kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset), publish_name=kpi_name)
    
    mdl.minimize(sum([kpi_sign * kpi_weight * ((kpi_expr * kpi_factor) - kpi_offset) for kpi_sign, kpi_weight, kpi_expr, kpi_factor, kpi_offset, kpi_name in kpis_expression_list]))
    
    # [ST_1] Constraint : cLinkSelectionToAllocationConstraint_cIterativeRelationalConstraint
    # Synchronize selection with CountyDemand allocations
    # Label: CT_1_Synchronize_selection_with_CountyDemand_allocations
    join_CountyDemand = list_of_CountyDemand.reset_index().merge(list_of_CountyDemand.reset_index(), left_on=['id_of_CountyDemand'], right_on=['id_of_CountyDemand'], suffixes=('', '_right')).set_index(['id_of_CountyDemand'])
    groupbyLevels = ['id_of_CountyDemand']
    groupby_CountyDemand = join_CountyDemand.allocationVar.groupby(level=groupbyLevels[0]).sum().to_frame(name='allocationVar')
    list_of_CountyDemand_maxValueAllocation = pd.Series([100000000] * len(list_of_CountyDemand)).to_frame('maxValueAllocation').set_index(list_of_CountyDemand.index)
    join_CountyDemand_2 = list_of_CountyDemand.join(list_of_CountyDemand_maxValueAllocation.maxValueAllocation, how='inner')
    join_CountyDemand_2['conditioned_maxValueAllocation'] = join_CountyDemand_2.selectionVar * join_CountyDemand_2.maxValueAllocation
    join_CountyDemand_3 = groupby_CountyDemand.join(join_CountyDemand_2.conditioned_maxValueAllocation, how='inner')
    for row in join_CountyDemand_3.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.allocationVar <= row.conditioned_maxValueAllocation, u'Synchronize selection with CountyDemand allocations', row)
    
    # [ST_2] Constraint : cLinkSelectionToAllocationConstraint_cIterativeRelationalConstraint
    # Synchronize selection with CountyDemand allocations
    # Label: CT_2_Synchronize_selection_with_CountyDemand_allocations
    join_CountyDemand = list_of_CountyDemand.reset_index().merge(list_of_CountyDemand.reset_index(), left_on=['id_of_CountyDemand'], right_on=['id_of_CountyDemand'], suffixes=('', '_right')).set_index(['id_of_CountyDemand'])
    groupbyLevels = ['id_of_CountyDemand']
    groupby_CountyDemand = join_CountyDemand.allocationVar.groupby(level=groupbyLevels[0]).sum().to_frame(name='allocationVar')
    list_of_CountyDemand_minValueAllocationForAssignment = pd.Series([0.10000000149011612] * len(list_of_CountyDemand)).to_frame('minValueAllocationForAssignment').set_index(list_of_CountyDemand.index)
    join_CountyDemand_2 = list_of_CountyDemand.join(list_of_CountyDemand_minValueAllocationForAssignment.minValueAllocationForAssignment, how='inner')
    join_CountyDemand_2['conditioned_minValueAllocationForAssignment'] = join_CountyDemand_2.selectionVar * join_CountyDemand_2.minValueAllocationForAssignment
    join_CountyDemand_3 = groupby_CountyDemand.join(join_CountyDemand_2.conditioned_minValueAllocationForAssignment, how='inner')
    for row in join_CountyDemand_3.itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.allocationVar >= row.conditioned_minValueAllocationForAssignment, u'Synchronize selection with CountyDemand allocations', row)
    
    # [ST_3] Constraint : cIterativeRelationalConstraint_cIterativeRelationalConstraint
    # For each CountyDemand, allocation is less than or equal to demand
    # Label: CT_3_For_each_CountyDemand__allocation_is_less_than_or_equal_to_demand
    for row in list_of_CountyDemand[list_of_CountyDemand.demand.notnull()].itertuples(index=True):
        helper_add_labeled_cplex_constraint(mdl, row.allocationVar <= row.demand, u'For each CountyDemand, allocation is less than or equal to demand', row)
    
    # [ST_4] Constraint : cGlobalRelationalConstraint_cGlobalRelationalConstraint
    # total CountyDemand allocations is less than or equal to max_budget of AllocationParameters
    # Label: CT_4_total_CountyDemand_allocations_is_less_than_or_equal_to_max_budget_of_AllocationParameters
    agg_CountyDemand_allocationVar_lhs = mdl.sum(list_of_CountyDemand.allocationVar)
    helper_add_labeled_cplex_constraint(mdl, agg_CountyDemand_allocationVar_lhs <= list_of_AllocationParameters.max_budget.iloc[0], u'total CountyDemand allocations is less than or equal to max_budget of AllocationParameters')


    return mdl


def solve_model(mdl):
    mdl.parameters.timelimit = 120
    # Call to custom code to update parameters value
    custom_code.update_solver_params(mdl.parameters)
    # Update parameters value according to environment variables definition
    cplex_param_env_prefix = 'ma.cplex.'
    cplex_params = [name.qualified_name for name in mdl.parameters.generate_params()]
    for param in cplex_params:
        env_param = cplex_param_env_prefix + param
        param_value = get_environment().get_parameter(env_param)
        if param_value:
            # Updating parameter value
            print("Updated value for parameter %s = %s" % (param, param_value))
            parameters = mdl.parameters
            for p in param.split('.')[1:]:
                parameters = parameters.__getattribute__(p)
            parameters.set(param_value)

    msol = mdl.solve(log_output=True)
    if not msol:
        print("!!! Solve of the model fails")
        if mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_SOLUTION or mdl.get_solve_status() == JobSolveStatus.INFEASIBLE_OR_UNBOUNDED_SOLUTION:
            crefiner = ConflictRefiner()
            conflicts = crefiner.refine_conflict(model, log_output=True)
            export_conflicts(conflicts)
            
    print('Solve status: %s' % mdl.get_solve_status())
    mdl.report()
    return msol


expr_to_info = {}


def export_conflicts(conflicts):
    # Display conflicts in console
    print('Conflict set:')
    list_of_conflicts = pd.DataFrame(columns=['constraint', 'context', 'detail'])
    for conflict, index in zip(conflicts, range(len(conflicts))):
        st = conflict.status
        ct = conflict.element
        label, context = expr_to_info.get(conflict.name, ('N/A', conflict.name))
        label_type = type(conflict.element)
        if isinstance(conflict.element, VarLbConstraintWrapper) \
                or isinstance(conflict.element, VarUbConstraintWrapper):
            label = 'Upper/lower bound conflict for variable: {}'.format(conflict.element._var)
            context = 'Decision variable definition'
            ct = conflict.element.get_constraint()

        # Print conflict information in console
        print("Conflict involving constraint: %s, \tfor: %s -> %s" % (label, context, ct))
        list_of_conflicts = list_of_conflicts.append({'constraint': label, 'context': str(context), 'detail': ct},
                                                     ignore_index=True)

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['list_of_conflicts'] = list_of_conflicts


def export_solution(msol):
    start_time = time.time()
    mdl = msol.model
    list_of_CountyDemand_solution = pd.DataFrame(index=list_of_CountyDemand.index)
    list_of_CountyDemand_solution['allocationVar'] = msol.get_values(list_of_CountyDemand.allocationVar.values)
    list_of_CountyDemand_solution = list_of_CountyDemand_solution.round({'allocationVar': 2})
    list_of_CountyDemand_solution['selectionVar'] = msol.get_values(list_of_CountyDemand.selectionVar.values)
    CountyDemand_allocation_solution = pd.DataFrame(index=list_of_CountyDemand.index)
    
    # Adding extra columns based on Solution Schema
    CountyDemand_allocation_solution['CountyDemand allocation decision'] = list_of_CountyDemand_solution['allocationVar']
    CountyDemand_allocation_solution['CountyDemand selection decision'] = list_of_CountyDemand_solution['selectionVar']
    CountyDemand_allocation_solution['CountyDemand county'] = list_of_CountyDemand['county']
    CountyDemand_allocation_solution['CountyDemand demand'] = list_of_CountyDemand['demand']
    CountyDemand_allocation_solution['CountyDemand product'] = list_of_CountyDemand['product_']
    list_of_CountyDemand_maxValueAllocation = pd.Series([100000000] * len(list_of_CountyDemand)).to_frame('maxValueAllocation').set_index(list_of_CountyDemand.index)
    join_CountyDemand = list_of_CountyDemand.join(list_of_CountyDemand_maxValueAllocation.maxValueAllocation, how='inner')
    CountyDemand_allocation_solution['CountyDemand maxValueAllocation'] = join_CountyDemand['maxValueAllocation']
    list_of_CountyDemand_minValueAllocationForAssignment = pd.Series([0.10000000149011612] * len(list_of_CountyDemand)).to_frame('minValueAllocationForAssignment').set_index(list_of_CountyDemand.index)
    join_CountyDemand = list_of_CountyDemand.join(list_of_CountyDemand_minValueAllocationForAssignment.minValueAllocationForAssignment, how='inner')
    CountyDemand_allocation_solution['CountyDemand minValueAllocationForAssignment'] = join_CountyDemand['minValueAllocationForAssignment']
    

    # Update of the ``outputs`` dict must take the 'Lock' to make this action atomic,
    # in case the job is aborted
    global output_lock
    with output_lock:
        outputs['CountyDemand_allocation_solution'] = CountyDemand_allocation_solution[['CountyDemand allocation decision', 'CountyDemand selection decision', 'CountyDemand county', 'CountyDemand demand', 'CountyDemand product', 'CountyDemand maxValueAllocation', 'CountyDemand minValueAllocationForAssignment']].reset_index()
        custom_code.post_process_solution(msol, outputs)

    elapsed_time = time.time() - start_time
    print('solution export done in ' + str(elapsed_time) + ' secs')
    return


# Import custom code definition if module exists
try:
    from custom_code import CustomCode
    custom_code = CustomCode(globals())
except ImportError:
    # Create a dummy anonymous object for custom_code
    custom_code = type('', (object,), {'preprocess': (lambda *args: None),
                                       'update_goals_list': (lambda *args: None),
                                       'update_model': (lambda *args: None),
                                       'update_solver_params': (lambda *args: None),
                                       'post_process_solution': (lambda *args: None)})()

# Custom pre-process
custom_code.preprocess()

print('* building wado model')
start_time = time.time()
model = build_model()

# Model customization
custom_code.update_model(model)

elapsed_time = time.time() - start_time
print('model building done in ' + str(elapsed_time) + ' secs')

print('* running wado model')
start_time = time.time()
msol = solve_model(model)
elapsed_time = time.time() - start_time
print('model solve done in ' + str(elapsed_time) + ' secs')
if msol:
    export_solution(msol)
